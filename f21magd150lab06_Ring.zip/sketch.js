let angle = 0;
function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
}


let myName = 'Mason';
function sayHello(name) {
  console.log('Hello ' + name + ',' + ' ' + 'welcome to the game' + '!');
}
sayHello(myName);



function draw() {
  background(220);
  noStroke(); //this noStroke is making it so that all my shapes made since then, being the 3 triangles for the triforce and all shapes for kirby, have no stroke applied to them

  {
  push();
  translate(250,250); //this translate is moving Kirbys point of origin for rotation from (0,0), to (250,250).
  rotate(angle);
  push();
  fill(255,192,203); //pink
  ellipse(200,100,100,100);
  ellipse(155,100,25,35);
  ellipse(245,100,25,35);
  pop();
  push();
  fill(141,2,31); //maroon
  ellipse(170,145,40,20);
  ellipse(230,145,40,20);
  pop();
  push();
  fill(0,0,0); //black
  ellipse(185,80,10,20);
  ellipse(215,80,10,20)
  pop();
  push();
  fill(255,150,203); //darker pink
  ellipse(170,100,20,10);
  ellipse(230,100,20,10);
  pop();
  push();
  fill(180,2,31); //red
  triangle(185,100,215,100,200,120)
  pop();
  push();
  fill(255,255,255);
  ellipse(185,75,5,10);
  ellipse(215,75,5,10);
  pop();
  angle = angle + 1 //this angle code is making it so that Kirby rotates at a continuous speed of + 1 degrees
  pop();
  }

triforceLeft(150,200,200,200,175,150);
triforceRight(200,200,250,200,225,150); //these 3 triforce shapes are assigning variables to the letter presented in the triforce functions in order to create shapes at the locations of said variables
triforceCenter(175,150,225,150,200,100);
  function triforceLeft(a,b,c,d,e,f) {
    fill(255,204,0);
    triangle(a,b,c,d,e,f);
  }
  function triforceRight(g,h,i,j,k,l){
    fill(255,204,0);
    triangle(g,h,i,j,k,l);
  }
  function triforceCenter(m,n,o,p,q,r){
    fill(255,204,0);
    triangle(m,n,o,p,q,r)
  }
  push();
  fill(0,0,0);
  rect(190,320,50,10);
  triangle(240,310,240,340,260,325);
  pop();
  push();
  fill(0,0,255);
  rect(300,250,50,100);
  rect(250,250,150,50)
  scale(0.5);
  translate(-50,300);
  fill(255,40,203);
  rect(300,250,50,100);
  rect(250,250,150,50);
  pop();
}