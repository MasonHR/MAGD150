function setup() {
  createCanvas(400, 400);
  
    frameRate(10);

  let x = 10;
print('The value of x is ' + x);
// prints "The value of x is 10"
  let y = 5;
print('The value of y is ' + y);
// prints "The value of y is 10"

  
  frameRate(30);
  textSize(30);
  textAlign(CENTER);
  
  

}


function draw() {
  background(200);
  text(frameCount, width / 2, height / 2);
    line(mouseX, 0, mouseX, 100);
  line(0, mouseY, 100, mouseY);
   line(mouseX, mouseY, pmouseX, pmouseY);
  print(pmouseX + ' -> ' + mouseX);
  
  
  fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(50, 50, 60, 60);
  fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(150, 50, 60, 60);fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(250, 50, 60, 60);
  fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(350, 50, 60, 60);
  
  fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(50, 350, 60, 60);
  fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(150, 350, 60, 60);fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(250, 350, 60, 60);
  fill(0);
  if (mouseY === pmouseY && mouseX === pmouseX) 
    ellipse(350, 350, 60, 60);
  
  push();
    let String1 = "12";
    let String2 = "12.5";
    let A = float(String1);
    let B = float(String2);
    textSize(16); 
    fill(color('red')); 
    text("Floating point representation of string '12' is: " + A, 200, 150);
    text("Floating point representation of string '12.9' is: " + B, 200, 250);
  pop();
  
  push();
  noFill();
  stroke(10);
  rect(4 + 2 * 8, 100, 60, 20);
  rect(960/3, 100, 60, 20);
  rect(10 + 10, 280, 60, 20);
  rect(400 - 80, 280, 60, 20);
  pop();

  push();
  let numArray = [2, 1, 5, 4, 8, 9];
  fill(0);
  noStroke();
  text('Array Elements', 200, 120);
  let spacing = 15;
  let elemsY = 190;
  for (let i = 0; i < numArray.length; i++) {
    text(numArray[i], i * spacing + (20), elemsY,);
  }
  let maxX = 33;
  let maxY = 80;
  textSize(32);
  text(max(numArray), maxX + 20, maxY + 150);
  pop();
  
  
  push();
  let numArray2 = [2, 1, 5, 4, 8, 9];
  fill(0);
  noStroke();
  text('Array Elements', 200, 300);
  let spacing2 = 15;
  let elemsY2 = 190;
  for (let i = 0; i < numArray2.length; i++) {
    text(numArray[i], i * spacing2 + (300), elemsY2);
  }
  let maxX2 = 33;
  let maxY2 = 80;
  textSize(32);
  text(min(numArray), maxX + 300, maxY + 150);
  pop();
  
  push();
  let leftWall = 150;
  let rightWall = 250;

  let xm = mouseX;
  let xc = constrain(mouseX, leftWall, rightWall);

  stroke(150);
  line(leftWall, 0, leftWall, height);
  line(rightWall, 0, rightWall, height);

  noStroke();
  fill(150);
  ellipse(xm, 33, 9, 9);
  fill(0);
  ellipse(xc, 66, 9, 9);
  pop();
}

