var cx = 300;
var cy = 311;
var cr = 12;

var radius = 150;
var angle = 0;
var speed = 0.05;
var centerX = 250;
var centerY = 260;

let button;
let Button;

function setup() {
  createCanvas(500, 500);

  Button = createButton('Ev');
  Button.position(235,300);
  Button.mousePressed(changeBG);
}
  function changeBG() {
  
  push();
  button = createButton('Ch');
  button.position(180,300);
  pop();
    
}


function draw() {
  background(220);
  
  push();
  ellipse(centerX, centerY, 10, 10);
  x = centerX + radius * cos(angle);
  y = centerY + radius * sin(angle);
  ellipse(x, y, 50, 50);
  angle = angle + speed;
  pop();
  
  push();
  fill(0,0,0);
  strokeWeight(2);
  stroke(0);
  rect(150,200,200,100);
  pop();
  
  push();
  fill(255,255,255);
  strokeWeight(1);
  stroke(255);
  rect(150,300,200,23);
  pop();
  
      
  push();
  if (overCircle(cx, cy, cr)) {
	fill(0, 102, 153);
	noStroke();
	} else {
    noFill();
	stroke(0, 102, 153);
	}
	ellipse(cx, cy, cr*2, cr*2);
      
    function overCircle(x, y, radius) {
	if (dist(x, y, mouseX, mouseY) < radius) {
	 return true;	
	} else {
	 return false;	
	} 
      
    }
}
