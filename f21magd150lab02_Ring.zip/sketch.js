function setup() {
  createCanvas(400, 400);
}

function draw() {
background('#222222');
  
push();
fill(204, 153, 0);
translate(-70,-35)
ellipse(200,200,150,150)
pop();
  

push();
fill(123, 160, 0);
translate(50, 0);
triangle(0, 50, 33, 33, 44, 66);
pop();


push();
fill(350, 100, 0);
  translate(250,0)
quad(38, 31, 86, 20, 69, 63, 30, 76);
pop();

  
push();
fill(100, 0, 100);
  translate(-50,200)
beginShape();
vertex(100, 120);
vertex(185, 120);
vertex(185, 175);
vertex(130, 175);
endShape(CLOSE);
  pop();

  push();
  translate(50, 90)
  fill(255,0,0)
  beginShape();
  vertex(330,180)
  vertex(250,180)
  vertex(220,95)
  vertex(180,180)
  vertex(100,180)
  vertex(165,235)
  vertex(140,305)
  vertex(215,265)
  vertex(290,305)
  vertex(265,235)
  endShape(CLOSE);
  
  line(-30, -15, 20, 20);
  
  push();
  translate(20,-10);
    line(-30, -15, 20, 20);
pop();
  
   push(); 
  translate(0,-10);
    line(-30, -15, 20, 20);
pop();
  
  
    push();
  translate(320,250);
    line(-30, -15, 20, 20);
pop();

      push();
  translate(300,250);
    line(-30, -15, 20, 20);
pop();
  
      push();
  translate(320,280);
    line(-30, -15, 20, 20);
pop();

  push();
  colorMode(RGB, 255);
let c = color(127, 255, 0);
ellipse(279, 50, 40, 60,);
  pop();
  
  
  
  
  
  }


  
  
  
  
  

